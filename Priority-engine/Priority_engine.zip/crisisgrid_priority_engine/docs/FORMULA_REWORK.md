# CrisisGrid priority formula: rework, evidence and validation

## 1. What the historical record says (15 events, 2008–2025)

Event table with coded factors, outcomes and sources: `training/historical_events.csv`.

| Event | Deaths + missing | People affected / displaced | What drove the outcome |
|---|---|---|---|
| Uttarakhand 2013 | ~6,054 | ~300,000 stranded | 4 days of rain + snowmelt, no public warning, 450+ road breaks, ~300k pilgrims cut off, helicopter ops limited by weather |
| Kerala 2018 | ~498 | 1.25M in 3,274 camps | Aug rain +164%, 35 of 54 dams opened for the first time, ~10,000 km roads lost, airport shut |
| Chennai 2015 | ~505 | 1.8M displaced | 490 mm/24h, 60% of the city without power, hospital failures (14 deaths at MIOT), airport shut |
| Bihar (Kosi) 2008 | 250–434 | 2.3–3M | Embankment breach, river changed course, ignored warning faxes, 300k houses destroyed |
| Kerala/Karnataka/Maharashtra 2019 | ~200 | ~1M | Dam releases, NH4 closed with 18,000 vehicles stranded |
| Himachal 2023 | 330+ (HP) | 70,000 tourists evacuated | A month's rain in a day, 1,000+ roads blocked |
| Sikkim GLOF 2023 | 92 + 75 missing (peak) | ~10,000 sheltered | Lake burst at midnight, 15 bridges and NH10 lost, early-warning system not yet live |
| Wayanad 2024 | 245–420 | n/a | Successive landslides in a small, vulnerable footprint |
| Dharali 2025 | ~71 | small village | Second cloudburst, only access route cut, helipad hit |
| Assam, UP, Tripura 2024; Punjab 2025; Gujarat 2024; Delhi 2023 | 1–109 | 20k–2.5M | Large affected populations with moderate lethality |

**Five lessons that shaped the new formula**

1. **Exposure explains scale, not lethality.** Across the 15 events, exposed population correlates ρ = 1.00 with people affected but only ρ = 0.23 with deaths. Hazard (0.76), isolation (0.72), escalation (0.63) and capacity failure (0.89) track lethality. Small, isolated, fast events (Dharali, Sikkim, Wayanad) kill disproportionately.
2. **The old additive formula can rank a dry dense city above a flooding village.** With equal weights, a 2.5M-person ward with no water scores ~30/100. With the rework it scores ~5.
3. **Capacity collapse is a separate failure mode.** In Chennai the shelters held while the hospitals and power grid failed. A plain average hides this, so the capacity term uses a power-mean (p = 3) in which the worst-failing system dominates.
4. **Isolation raises need.** Cut-off zones (Uttarakhand, Sikkim, Himachal, Dharali) cannot self-evacuate. Reachability is a *routing* concern; the priority term records *need*.
5. **Vulnerability was missing.** Bihar 2008 and Assam show repeated, concentrated harm in poor, kutcha-housing, elderly/child-heavy settlements. It is now the 6th term.

Design insight: the allocation objective in the report (§4.5) is `max Σ Priority(i) × Served_Demand(i)`. *Scale already enters through demand*, so Priority must also express **urgency per person**. That is why exposure is capped at 30% of the weight and a life-threat uplift exists.

## 2. The reworked formula

```
Priority(i) = min( 100,  100 · Gate(i) · [ w1·Exposure + w2·IncidentGrowth + w3·HazardSeverity
                                            + w4·CapacityStress + w5·InfrastructureRisk + w6·Vulnerability ]
                         + LifeThreatUplift(i) )

Gate(i)             = 0.10 + 0.90 · clip(HazardSeverity / 0.30, 0, 1)     (no flood hazard => little priority)
LifeThreatUplift(i) = 8 · smoothstep( (cbrt(Hazard · Isolation · Growth) − 0.55) / 0.30 )
```

| Term | Weight | Definition (all in [0,1]) |
|---|---|---|
| Exposure | **0.300** | log10(people in flood footprint, incl. transient pilgrims/tourists), 10² → 0, 10^6.5 → 1 |
| IncidentGrowth | **0.132** | log2 growth of incidents hour-on-hour (8× → 1, +2 smoothing) averaged with river rise rate (30 cm/h → 1) |
| HazardSeverity | **0.112** | Noisy-OR of IMD rainfall class (64.5 / 115.6 / 204.5 mm), river level above danger ÷ headroom, depth and depth×velocity; × hazard-type multiplier (flash flood / landslide / GLOF 1.0 … riverine 0.85) |
| CapacityStress | **0.170** | Power-mean (p = 3) of shelter load, non-functional hospitals, rescue-asset gap |
| InfrastructureRisk | **0.117** | 0.35 isolation (routes cut ÷ total) + 0.25 roads blocked + 0.20 worst lifeline outage + 0.20 critical facilities hit |
| Vulnerability (new) | **0.169** | 0.6 × (children/elderly/disabled %) + 0.4 × kutcha-housing % |

The missing-data rule: a sub-index uses only the fields supplied. If nothing is supplied it is imputed with a neutral value and the response lists it under `missing_inputs`. If hazard or exposure is entirely missing, the tier is `UNVERIFIED` rather than a made-up level.

## 3. How the weights were obtained

No public dataset records which zone *should* have been served first, so the weights are **triangulated** from two sources and then bounded:

1. **Simulator (domain-randomised).** 30 randomised outcome models × 120 scenarios × 40 zones across six hazard archetypes (riverine plain, urban pluvial, mountain flash, landslide, dam release, GLOF), calibrated to the event table. Weights are fitted with a listwise (ListNet/KL) loss. They put ~75% on exposure, because in a model where need ∝ people, population dominates.
2. **Historical events.** Ridge-on-simplex regression of a composite outcome (rank of deaths + rank of people affected) on the six coded factors; the shrinkage λ is chosen by leave-one-event-out CV, and bootstrap bands are stored.
3. **Blend 50/50 and project onto governance bounds [0.06, 0.30]**, so no factor is ignored and none dominates. Exposure sits at its upper bound (the simulator wanted ~0.75), so that weight reflects policy as much as data.

| | Exposure | Growth | Hazard | Capacity | Infra | Vulnerability |
|---|---|---|---|---|---|---|
| Simulator only | 0.749 | 0.042 | 0.100 | 0.026 | 0.046 | 0.038 |
| Historical events only | 0.231 | 0.145 | 0.047 | 0.239 | 0.111 | 0.225 |
| **Final (bounded blend)** | **0.300** | **0.132** | **0.112** | **0.170** | **0.117** | **0.169** |

A GBM trained on the same simulator runs as a *shadow model*: if its score differs from the formula by more than 20 points, the zone is flagged for human review.

## 4. Validation (full numbers in `docs/evaluation_report.json`)

**Real events, leave-one-event-out (n = 15)** — Spearman ρ between engine score and outcome:

| Method | vs deaths+missing | vs people affected | vs composite |
|---|---|---|---|
| **Final engine** | **0.92** | **0.52** | **0.92** |
| Original 5-term, equal weights | 0.92 | 0.16 | 0.72 |
| Exposure only | 0.23 | 1.00 | 0.77 |
| Simulator-only weights | 0.49 | 0.94 | 0.91 |

Only the final engine does reasonably on *both* lethality and scale.

**Held-out simulated scenarios (unseen outcome models):** share of true need captured by the engine's top-5 zones: original equal-weight 0.62, final 0.69. A GBM that never saw the archetype scores 0.97, so there is headroom a transparent formula gives up.

**Robustness:** randomly perturbing the weights (Dirichlet, concentration 40) keeps rankings very similar (mean Kendall τ = 0.91, min 0.85). The gate parameters barely matter (need captured 0.757–0.758 across 9 settings). Adding ±0.1 coding noise to the historical factors still gives ρ ≈ 0.77 (5–95%: 0.66–0.86) on the additive core.

**Policy dial: life-threat uplift (max points).** More uplift means better lethality ranking and worse scale ranking:

| Max uplift | Sim need captured@5 | Events ρ lethality | Events ρ scale |
|---|---|---|---|
| 0 | 0.758 | 0.83 | 0.69 |
| 4 | 0.726 | 0.86 | 0.62 |
| **8 (shipped)** | **0.690** | **0.92** | **0.45** |
| 12 | 0.664 | 0.96 | 0.36 |
| 20 | 0.622 | 0.95 | 0.23 |

Change `escalation.max_uplift` in `crisisgrid_priority/artifacts/weights.json` to move along this frontier.

## 5. Limitations (please state these in your report)

- **The weights are calibrated, not proven.** There are no zone-level ground-truth priority labels for India. The simulator encodes my assumptions about how need arises, and the 15 events are a small sample.
- **Factor scores for the historical events are analyst judgement.** I coded G, H, C, I, V (0–1) from the cited facts *after* knowing the outcomes, which can inflate their correlation with deaths. Exposure is computed from the figures. The CSV includes notes so you can audit or re-code any row.
- **Two exposure figures (Wayanad, Dharali) are estimates, not sourced.** Fatality and affected counts differ between sources; ranges are noted in the CSV.
- Headline figures come from Wikipedia event pages and press reports, not primary NDMA/SDMA situation reports. Replace them with official figures before final submission.
- `UNVERIFIED`, the thresholds and the uplift are policy choices that should be agreed with stakeholders (as your report §4.3 already says).
- Retrain on real labels (rescue requests served, camp occupancy, 112 call logs) as soon as you have them: `python training/train.py`.

## Sources

- [2013 North India floods](https://en.wikipedia.org/wiki/2013_North_India_floods)
- [2018 Kerala floods](https://en.wikipedia.org/wiki/2018_Kerala_floods)
- [2015 South Indian floods](https://en.wikipedia.org/wiki/2015_South_Indian_floods)
- [2008 Bihar flood](https://en.wikipedia.org/wiki/2008_Bihar_flood)
- [2019 Indian floods](https://en.wikipedia.org/wiki/2019_Indian_floods)
- [2023 North India floods](https://en.wikipedia.org/wiki/2023_North_India_floods)
- [2023 Sikkim flash floods](https://en.wikipedia.org/wiki/2023_Sikkim_flash_floods)
- [2024 India floods](https://en.wikipedia.org/wiki/2024_India_floods)
- [2025 Punjab (India) floods](https://en.wikipedia.org/wiki/2025_Punjab,_India_floods)
- [2025 Uttarakhand flash flood](https://en.wikipedia.org/wiki/2025_Uttarakhand_flash_flood)
- Press: [Wayanad toll (Morung Express/IANS)](https://morungexpress.com/wayanad-tragedy-toll-reaches-245-240-people-missing-war-of-words-begins-between-centre-and-kerala), [Assam floods (Deccan Herald)](https://www.deccanherald.com/india/devastating-floods-hit-assam-25-lakh-people-still-suffering-3055096)
