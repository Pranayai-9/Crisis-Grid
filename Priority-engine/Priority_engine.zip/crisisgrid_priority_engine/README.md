# CrisisGrid Priority Engine v2

Explainable zone-priority scoring for flood response (BAI506 mini project, report §4.3).
Full rationale, evidence and validation: [`docs/FORMULA_REWORK.md`](docs/FORMULA_REWORK.md).

```
Priority(i) = min(100, 100·Gate(i)·[w1·Exposure + w2·IncidentGrowth + w3·HazardSeverity
                                     + w4·CapacityStress + w5·InfrastructureRisk + w6·Vulnerability]
                       + LifeThreatUplift(i))
weights: 0.300 / 0.132 / 0.112 / 0.170 / 0.117 / 0.169
```

## Run

```bash
pip install -r requirements.txt
uvicorn crisisgrid_priority.api:app --port 8000      # Swagger UI: http://localhost:8000/docs
pytest -q                                            # 14 tests
python training/train.py                             # retrain -> crisisgrid_priority/artifacts/
python training/evaluate.py                          # benchmarks -> docs/evaluation_report.json
```

Optional auth: `export CRISISGRID_API_KEY=secret` and send `X-API-Key: secret`.
Docker: `docker build -t crisisgrid-priority . && docker run -p 8000:8000 crisisgrid-priority`.

## API

| Method & path | Purpose |
|---|---|
| `GET /health` | liveness |
| `GET /v1/model` | formula, weights, thresholds, training metadata |
| `POST /v1/priority/score` | score one zone, with sub-indices, per-factor points, top drivers, explanation, confidence |
| `POST /v1/priority/rank` | score and rank up to 5,000 zones; returns `optimizer_weight` (sums to 1) for `max Σ Priority·Served` |

Every field except `zone_id` is optional; send what you have. Field groups: exposure
(`population`, `flooded_fraction`, `transient_population` …), growth (`incidents_last_1h`, `incidents_prev_1h`,
`water_level_rise_cm_per_h`), hazard (`hazard_type`, `rainfall_24h_mm`, `river_level_above_danger_m`,
`max_inundation_depth_m`, `flow_velocity_mps` …), capacity (`displaced_people`, `shelter_capacity`,
`hospitals_nonfunctional_pct`, `rescue_assets_*`), infrastructure (`roads_blocked_pct`, `access_routes_total/cut`,
`power_outage_pct`, `comm_outage_pct`, `critical_facilities_*`), vulnerability (`vulnerable_pop_pct`, `kutcha_housing_pct`).
The full schema is in `/docs`.

```bash
curl -s -X POST localhost:8000/v1/priority/rank -H 'content-type: application/json' -d @examples/rank_request.json
```

Abridged response (one zone):

```json
{"zone_id":"Z2","priority_score":65.18,"tier":"HIGH","base_score":57.18,"life_threat_escalation":true,
 "hazard_gate":1.0,"top_drivers":[{"factor":"infrastructure_risk","index":0.975,"contribution_points":11.39,"imputed":false}],
 "missing_inputs":["capacity_stress"],"confidence":0.83,"ml_shadow_score":49.96,"model_disagreement":false,
 "explanation":"Dharali-type flash-flood hamlet: HIGH priority (65/100). Main drivers: ... LIFE-THREAT ESCALATION ...",
 "rank":3,"optimizer_weight":0.321}
```

Tiers: `CRITICAL ≥ 67.6`, `HIGH ≥ 58.1`, `MODERATE ≥ 46.1`, else `LOW`; `UNVERIFIED` when hazard or exposure data is absent.

Python use without HTTP:

```python
from crisisgrid_priority import PriorityEngine
ranked = PriorityEngine().rank(list_of_zone_dicts)
```

## Layout

```
crisisgrid_priority/   features.py (raw -> 6 indices) · engine.py (formula) · api.py · schemas.py · artifacts/ (weights.json, GBM shadow)
training/              historical_events.csv · simulate.py · train.py · evaluate.py
tests/                 engine + API tests
docs/                  FORMULA_REWORK.md · evaluation_report.json
```

## Status

Prototype decision-support component. Weights are calibrated on simulated scenarios and 15 coded historical events,
not on real operational labels. Do not use as the sole basis for operational decisions.
