import json, os, sys
import numpy as np
import pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from crisisgrid_priority import features as F
from crisisgrid_priority.engine import PriorityEngine, FACTORS

eng = PriorityEngine()

DRY_CITY = dict(zone_id="a", population=2_500_000, flooded_fraction=0.0, rainfall_24h_mm=5)
HAMLET = dict(zone_id="b", hazard_type="flash_flood", population=1800, flooded_fraction=0.7, transient_population=600,
              rainfall_24h_mm=230, max_inundation_depth_m=2.5, flow_velocity_mps=3.0, incidents_last_1h=9, incidents_prev_1h=1,
              access_routes_total=1, access_routes_cut=1, roads_blocked_pct=100, comm_outage_pct=90, vulnerable_pop_pct=30)


def test_weights_valid():
    assert abs(sum(eng.w.values()) - 1) < 1e-9
    assert all(0.05 <= v <= 0.31 for v in eng.w.values())          # governance bounds
    assert set(eng.w) == set(FACTORS)


def test_indices_in_unit_interval():
    rng = np.random.default_rng(0)
    for _ in range(300):
        obs = dict(population=float(10 ** rng.uniform(1, 7)), flooded_fraction=float(rng.uniform()),
                   rainfall_24h_mm=float(rng.uniform(0, 600)), river_level_above_danger_m=float(rng.uniform(-3, 8)),
                   max_inundation_depth_m=float(rng.uniform(0, 6)), flow_velocity_mps=float(rng.uniform(0, 6)),
                   incidents_last_1h=int(rng.integers(0, 200)), incidents_prev_1h=int(rng.integers(0, 200)),
                   displaced_people=float(rng.uniform(0, 1e6)), shelter_capacity=float(rng.uniform(0, 1e6)),
                   hospitals_nonfunctional_pct=float(rng.uniform(0, 100)), roads_blocked_pct=float(rng.uniform(0, 100)),
                   vulnerable_pop_pct=float(rng.uniform(0, 100)), kutcha_housing_pct=float(rng.uniform(0, 100)))
        for v in F.compute_indices(obs).values():
            assert v is None or 0.0 <= v <= 1.0
        r = eng.score_zone(obs)
        assert 0.0 <= r["score"] <= 100.0


def test_monotone_in_each_driver():
    base = dict(hazard_type="riverine", population=100_000, flooded_fraction=0.3, rainfall_24h_mm=120,
                incidents_last_1h=5, incidents_prev_1h=5, displaced_people=5000, shelter_capacity=10000,
                roads_blocked_pct=20, vulnerable_pop_pct=15)
    s0 = eng.score_zone(base)["score"]
    for k, v in dict(flooded_fraction=0.6, rainfall_24h_mm=250, incidents_last_1h=40, displaced_people=30000,
                     roads_blocked_pct=80, vulnerable_pop_pct=40).items():
        assert eng.score_zone({**base, k: v})["score"] > s0, k


def test_hazard_gate_dry_city_not_above_flooded_hamlet():
    assert eng.score_zone(DRY_CITY)["score"] < 10
    assert eng.score_zone(HAMLET)["score"] > 3 * eng.score_zone(DRY_CITY)["score"]
    assert eng.score_zone(DRY_CITY)["tier"] == "LOW"


def test_life_threat_uplift_applies_to_trapped_escalating_hazard():
    r = eng.score_zone(HAMLET)
    assert r["escalation_applied"] and r["score"] > r["base_score"]
    calm = {**HAMLET, "incidents_last_1h": 1, "incidents_prev_1h": 9}
    assert not eng.score_zone(calm)["escalation_applied"]


def test_missing_data_handling():
    r = eng.score_zone({"zone_id": "x"})
    assert r["tier"] == "UNVERIFIED" and r["confidence"] == 0.0 and len(r["missing_inputs"]) == 6
    assert "UNVERIFIED" in r["explanation"]


def test_capacity_power_mean_worst_system_dominates():
    only_hosp = F.capacity_index(hospitals_nonfunctional_pct=50)            # hospitals fully down
    mixed = F.capacity_index(displaced_people=0, shelter_capacity=1000, hospitals_nonfunctional_pct=50)
    assert only_hosp == 1.0 and mixed > 0.6                                   # shelter fine, hospitals down -> still high


def test_exposure_counts_transient_people():
    assert F.exposure_index(population=500, flooded_fraction=1, transient_population=50_000) > \
        F.exposure_index(population=500, flooded_fraction=1)


def test_rank_sorted_and_weights_sum_to_one():
    zones = [DRY_CITY, HAMLET, {**HAMLET, "zone_id": "c", "population": 90_000}]
    r = eng.rank(zones)
    scores = [x["score"] for x in r]
    assert scores == sorted(scores, reverse=True) and [x["rank"] for x in r] == [1, 2, 3]
    assert abs(sum(x["optimizer_weight"] for x in r) - 1) < 1e-9
