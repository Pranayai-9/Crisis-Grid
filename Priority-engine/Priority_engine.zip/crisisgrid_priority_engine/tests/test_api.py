import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from fastapi.testclient import TestClient
from crisisgrid_priority.api import app

c = TestClient(app)
EX = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "examples", "rank_request.json")


def test_health_and_model():
    assert c.get("/health").json()["status"] == "ok"
    m = c.get("/v1/model").json()
    assert abs(sum(m["weights"].values()) - 1) < 1e-6 and "Priority(i)" in m["formula"]


def test_score_endpoint():
    z = json.load(open(EX))["zones"][1]
    r = c.post("/v1/priority/score", json=z)
    assert r.status_code == 200
    b = r.json()
    assert 0 <= b["priority_score"] <= 100 and b["tier"] in {"CRITICAL", "HIGH", "MODERATE", "LOW"}
    assert b["life_threat_escalation"] is True and len(b["top_drivers"]) == 3 and b["explanation"]


def test_rank_endpoint_and_top_k():
    req = json.load(open(EX))
    r = c.post("/v1/priority/rank", json=req).json()
    assert r["n_zones"] == 4 and [z["rank"] for z in r["ranking"]] == [1, 2, 3, 4]
    assert r["ranking"][-1]["zone_id"] == "Z1"                      # dry dense city is last
    assert sum(r["tier_counts"].values()) == 4
    r2 = c.post("/v1/priority/rank", json={**req, "top_k": 2}).json()
    assert len(r2["ranking"]) == 2 and r2["n_zones"] == 4


def test_validation_errors():
    assert c.post("/v1/priority/score", json={"zone_id": "x", "access_routes_total": 1, "access_routes_cut": 2}).status_code == 422
    assert c.post("/v1/priority/score", json={"zone_id": "x", "flooded_fraction": 1.5}).status_code == 422
    assert c.post("/v1/priority/score", json={"zone_id": "x", "bogus": 1}).status_code == 422
    dup = {"zones": [{"zone_id": "a"}, {"zone_id": "a"}]}
    assert c.post("/v1/priority/rank", json=dup).status_code == 422


def test_api_key(monkeypatch):
    monkeypatch.setenv("CRISISGRID_API_KEY", "secret")
    assert c.get("/v1/model").status_code == 401
    assert c.get("/v1/model", headers={"X-API-Key": "secret"}).status_code == 200
    assert c.get("/health").status_code == 200
