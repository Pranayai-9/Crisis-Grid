"""CrisisGrid Priority Engine - REST API.

    uvicorn crisisgrid_priority.api:app --port 8000
    open http://localhost:8000/docs
Optional auth: set CRISISGRID_API_KEY and send header  X-API-Key: <key>.
"""
from __future__ import annotations

import os
from collections import Counter
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException

from .engine import PriorityEngine
from .schemas import ModelInfo, RankRequest, RankResponse, ZoneInput, ZoneScore

app = FastAPI(
    title="CrisisGrid Priority Engine",
    version="2.0.0",
    description="Explainable zone-priority scoring for flood response (CrisisGrid, BAI506 mini project). "
                "Priority = 100 x Gate x [w1 Exposure + w2 IncidentGrowth + w3 HazardSeverity + w4 CapacityStress "
                "+ w5 InfrastructureRisk + w6 Vulnerability] + life-threat uplift. Decision support only.",
)
_engine = PriorityEngine()


def get_engine() -> PriorityEngine:
    return _engine


def check_key(x_api_key: Optional[str] = Header(default=None)):
    required = os.environ.get("CRISISGRID_API_KEY")
    if required and x_api_key != required:
        raise HTTPException(status_code=401, detail="invalid or missing X-API-Key")


def _to_obs(z: ZoneInput) -> dict:
    d = z.model_dump(exclude_none=True)
    if "hazard_type" in d:
        d["hazard_type"] = d["hazard_type"].value if hasattr(d["hazard_type"], "value") else d["hazard_type"]
    return d


def _fmt(res: dict, version: str, zone_id: str, name) -> dict:
    return {
        "zone_id": zone_id, "name": name,
        "priority_score": round(res["score"], 2), "tier": res["tier"],
        "base_score": round(res["base_score"], 2), "life_threat_escalation": res["escalation_applied"],
        "hazard_gate": round(res["gate"], 3),
        "indices": {k: round(v, 4) for k, v in res["indices"].items()},
        "contributions": {k: round(v, 2) for k, v in res["contributions"].items()},
        "top_drivers": res["drivers"], "missing_inputs": res["missing_inputs"],
        "confidence": round(res["confidence"], 3),
        "ml_shadow_score": None if res["ml_shadow_score"] is None else round(res["ml_shadow_score"], 2),
        "model_disagreement": res["model_disagreement"], "explanation": res["explanation"],
        "model_version": version,
    }


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok", "model_version": _engine.card.version}


@app.get("/v1/model", response_model=ModelInfo, tags=["meta"], dependencies=[Depends(check_key)])
def model_info(engine: PriorityEngine = Depends(get_engine)):
    c = engine.card
    return ModelInfo(
        version=c.version,
        formula="Priority(i) = min(100, 100*Gate(i)*[w1*Exposure + w2*IncidentGrowth + w3*HazardSeverity + "
                "w4*CapacityStress + w5*InfrastructureRisk + w6*Vulnerability] + LifeThreatUplift(i))",
        weights=engine.w, gate_min=c.gate_min, gate_tau=c.gate_tau, escalation=c.escalation,
        tier_thresholds=c.tiers, trained_utc=c.meta.get("trained_utc"), method=c.meta.get("method"),
        disclaimer=c.meta.get("disclaimer"))


@app.post("/v1/priority/score", response_model=ZoneScore, tags=["priority"], dependencies=[Depends(check_key)])
def score_zone(zone: ZoneInput, engine: PriorityEngine = Depends(get_engine)):
    """Score one zone and explain the result."""
    res = engine.score_zone(_to_obs(zone))
    return _fmt(res, engine.card.version, zone.zone_id, zone.name)


@app.post("/v1/priority/rank", response_model=RankResponse, tags=["priority"], dependencies=[Depends(check_key)])
def rank_zones(req: RankRequest, engine: PriorityEngine = Depends(get_engine)):
    """Score and rank many zones. `optimizer_weight` plugs into  max sum_i Priority_i x Served_i."""
    ranked = engine.rank([_to_obs(z) for z in req.zones])
    out = []
    for r in ranked:
        row = _fmt(r, engine.card.version, r["zone_id"], r["name"])
        row["rank"] = r["rank"]
        row["optimizer_weight"] = round(r["optimizer_weight"], 6)
        out.append(row)
    counts = Counter(r["tier"] for r in out)
    if req.top_k:
        out = out[: req.top_k]
    return {"model_version": engine.card.version, "n_zones": len(ranked),
            "tier_counts": {t: counts.get(t, 0) for t in ("CRITICAL", "HIGH", "MODERATE", "LOW", "UNVERIFIED")}, "ranking": out}
