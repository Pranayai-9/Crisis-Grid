"""Raw zone observations -> six normalised sub-indices in [0, 1].

Every function here is deterministic, unit-tested and documented, so each
priority score can be traced back to physical inputs (FR5 / interpretability NFR).
Missing inputs are handled explicitly: a sub-index is built only from the
fields that were supplied, and is reported as ``None`` when nothing was supplied.
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, Optional

import numpy as np

# ----------------------------------------------------------------------------
# Tunable normalisation constants (policy parameters, documented in README)
# ----------------------------------------------------------------------------
EXPOSURE_LOG_LO = 2.0   # 100 exposed people  -> 0
EXPOSURE_LOG_HI = 6.5   # ~3.2 million people -> 1
# IMD 24h rainfall classes (mm): heavy 64.5, very heavy 115.6, extremely heavy 204.5
RAIN_KNOTS_MM = [0, 64.5, 115.6, 204.5, 300.0]
RAIN_KNOTS_SC = [0.0, 0.30, 0.60, 0.85, 1.00]
DEPTH_KNOTS_M = [0, 0.5, 1.0, 2.0, 3.0]
DEPTH_KNOTS_SC = [0.0, 0.40, 0.65, 0.90, 1.00]
DV_KNOTS = [0.0, 0.6, 1.2, 2.0]            # depth x velocity (m2/s) life-hazard thresholds
DV_KNOTS_SC = [0.0, 0.50, 0.80, 1.00]
RISE_CM_PER_H_FOR_MAX = 30.0               # river rising 30 cm/h -> growth 1
DEFAULT_HEADROOM_M = 3.0                   # danger level -> HFL headroom if not supplied
CAPACITY_POWER_MEAN_P = 3.0                # worst-shortage-dominates aggregation

HAZARD_TYPE_MULTIPLIER = {
    "riverine": 0.85,
    "urban_pluvial": 0.85,
    "coastal": 0.95,
    "dam_release": 0.95,
    "flash_flood": 1.00,
    "landslide": 1.00,
    "glof": 1.00,
}

FACTORS = ["exposure", "incident_growth", "hazard_severity",
           "capacity_stress", "infrastructure_risk", "vulnerability"]


def _clip01(x: float) -> float:
    return float(min(1.0, max(0.0, x)))


def _present(v) -> bool:
    return v is not None and not (isinstance(v, float) and math.isnan(v))


def _mean(vals: Iterable[Optional[float]]) -> Optional[float]:
    v = [x for x in vals if x is not None]
    return float(np.mean(v)) if v else None


def _wmean(pairs) -> Optional[float]:
    """Weighted mean over (value, weight) pairs, ignoring missing values."""
    num = den = 0.0
    for val, w in pairs:
        if val is not None:
            num += val * w
            den += w
    return num / den if den > 0 else None


# ----------------------------------------------------------------------------
# 1. Exposure
# ----------------------------------------------------------------------------
def exposure_index(population=None, flooded_fraction=None, forecast_flooded_fraction_6h=None,
                   transient_population=None, population_exposed=None) -> Optional[float]:
    """Log-scaled people in (or about to be in) the hazard footprint.

    Transient people (pilgrims, tourists, labour camps) are counted explicitly -
    they were a decisive hidden exposure in Uttarakhand 2013, Himachal 2023, Sikkim 2023.
    """
    if _present(population_exposed):
        exposed = float(population_exposed)
    elif _present(population):
        fracs = [f for f in (flooded_fraction, forecast_flooded_fraction_6h) if _present(f)]
        if not fracs:
            return None
        frac = max(fracs)
        exposed = float(population) * _clip01(frac)
    else:
        if not _present(transient_population):
            return None
        exposed = 0.0
    exposed += float(transient_population) if _present(transient_population) else 0.0
    return _clip01((math.log10(exposed + 1.0) - EXPOSURE_LOG_LO) / (EXPOSURE_LOG_HI - EXPOSURE_LOG_LO))


# ----------------------------------------------------------------------------
# 2. Incident growth (escalation rate)
# ----------------------------------------------------------------------------
def growth_index(incidents_last_1h=None, incidents_prev_1h=None, water_level_rise_cm_per_h=None) -> Optional[float]:
    """Escalation = growth in reported incidents and/or speed of river rise (leading indicator)."""
    inc = None
    if _present(incidents_last_1h) and _present(incidents_prev_1h):
        ratio = (incidents_last_1h + 2.0) / (incidents_prev_1h + 2.0)   # +2: damp small-count noise
        inc = _clip01(math.log2(ratio) / 3.0)                           # 8x growth -> 1
    rise = None
    if _present(water_level_rise_cm_per_h):
        rise = _clip01(water_level_rise_cm_per_h / RISE_CM_PER_H_FOR_MAX)
    return _mean([inc, rise])


# ----------------------------------------------------------------------------
# 3. Hazard severity
# ----------------------------------------------------------------------------
def hazard_index(hazard_type=None, rainfall_24h_mm=None, rainfall_forecast_6h_mm=None,
                 river_level_above_danger_m=None, river_headroom_m=None,
                 max_inundation_depth_m=None, flow_velocity_mps=None) -> Optional[float]:
    """Noisy-OR of rainfall, river and depth/velocity evidence x hazard-type lethality multiplier."""
    scores = []
    if _present(rainfall_24h_mm) or _present(rainfall_forecast_6h_mm):
        eff = (rainfall_24h_mm or 0.0) + 0.5 * (rainfall_forecast_6h_mm or 0.0)
        scores.append(float(np.interp(eff, RAIN_KNOTS_MM, RAIN_KNOTS_SC)))
    if _present(river_level_above_danger_m):
        head = river_headroom_m if _present(river_headroom_m) and river_headroom_m > 0 else DEFAULT_HEADROOM_M
        scores.append(_clip01(river_level_above_danger_m / head))
    if _present(max_inundation_depth_m):
        s = float(np.interp(max_inundation_depth_m, DEPTH_KNOTS_M, DEPTH_KNOTS_SC))
        if _present(flow_velocity_mps):
            s = max(s, float(np.interp(max_inundation_depth_m * flow_velocity_mps, DV_KNOTS, DV_KNOTS_SC)))
        scores.append(s)
    if not scores:
        return None
    intensity = 1.0 - float(np.prod([1.0 - s for s in scores]))
    mult = HAZARD_TYPE_MULTIPLIER.get(hazard_type or "", 0.90)
    return _clip01(intensity * mult)


# ----------------------------------------------------------------------------
# 4. Capacity stress
# ----------------------------------------------------------------------------
def capacity_index(displaced_people=None, shelter_capacity=None, hospitals_nonfunctional_pct=None,
                   rescue_assets_available=None, rescue_assets_required=None) -> Optional[float]:
    """Local demand vs capacity. Power-mean (p=3) so one collapsing system dominates
    (Chennai 2015: hospitals failed while shelters coped)."""
    comps = []
    if _present(displaced_people) and _present(shelter_capacity):
        load = float(displaced_people) / max(float(shelter_capacity), 1.0)
        comps.append(_clip01((load - 0.5) / 1.0))          # <=50% full -> 0 ; >=150% -> 1
    elif _present(displaced_people) and not _present(shelter_capacity) and displaced_people > 0:
        comps.append(1.0)                                    # people displaced, no shelter capacity known
    if _present(hospitals_nonfunctional_pct):
        comps.append(_clip01(hospitals_nonfunctional_pct / 50.0))
    if _present(rescue_assets_available) and _present(rescue_assets_required) and rescue_assets_required > 0:
        comps.append(_clip01(1.0 - rescue_assets_available / rescue_assets_required))
    if not comps:
        return None
    p = CAPACITY_POWER_MEAN_P
    return _clip01((float(np.mean([c ** p for c in comps]))) ** (1.0 / p))


# ----------------------------------------------------------------------------
# 5. Infrastructure risk (access + lifelines)
# ----------------------------------------------------------------------------
def infrastructure_index(roads_blocked_pct=None, access_routes_total=None, access_routes_cut=None,
                         power_outage_pct=None, comm_outage_pct=None,
                         critical_facilities_total=None, critical_facilities_affected=None) -> Optional[float]:
    """Isolation, road loss, lifeline outage and critical-facility exposure.

    A zone that is cut off *needs more* priority (it cannot self-evacuate); feasibility of reaching it
    is a separate concern handled by the routing/optimisation stage.
    """
    iso = None
    if _present(access_routes_total) and access_routes_total > 0 and _present(access_routes_cut):
        iso = _clip01(float(access_routes_cut) / float(access_routes_total))
    road = _clip01(roads_blocked_pct / 100.0) if _present(roads_blocked_pct) else None
    util_vals = [x for x in (power_outage_pct, comm_outage_pct) if _present(x)]
    util = _clip01(max(util_vals) / 100.0) if util_vals else None   # worst lifeline governs
    crit = None
    if _present(critical_facilities_total) and critical_facilities_total > 0 and _present(critical_facilities_affected):
        crit = _clip01(float(critical_facilities_affected) / float(critical_facilities_total))
    return _wmean([(iso, 0.35), (road, 0.25), (util, 0.20), (crit, 0.20)])


# ----------------------------------------------------------------------------
# 6. Vulnerability (new term)
# ----------------------------------------------------------------------------
def vulnerability_index(vulnerable_pop_pct=None, kutcha_housing_pct=None) -> Optional[float]:
    """Share of children<5, elderly 65+, disabled/pregnant + fragile (kutcha) housing."""
    a = _clip01(vulnerable_pop_pct / 50.0) if _present(vulnerable_pop_pct) else None
    b = _clip01(kutcha_housing_pct / 80.0) if _present(kutcha_housing_pct) else None
    return _wmean([(a, 0.6), (b, 0.4)])


def compute_indices(obs: Dict) -> Dict[str, Optional[float]]:
    """Map a flat dict of raw observations to the six sub-indices."""
    g = obs.get
    return {
        "exposure": exposure_index(g("population"), g("flooded_fraction"), g("forecast_flooded_fraction_6h"),
                                   g("transient_population"), g("population_exposed")),
        "incident_growth": growth_index(g("incidents_last_1h"), g("incidents_prev_1h"), g("water_level_rise_cm_per_h")),
        "hazard_severity": hazard_index(g("hazard_type"), g("rainfall_24h_mm"), g("rainfall_forecast_6h_mm"),
                                        g("river_level_above_danger_m"), g("river_headroom_m"),
                                        g("max_inundation_depth_m"), g("flow_velocity_mps")),
        "capacity_stress": capacity_index(g("displaced_people"), g("shelter_capacity"),
                                          g("hospitals_nonfunctional_pct"),
                                          g("rescue_assets_available"), g("rescue_assets_required")),
        "infrastructure_risk": infrastructure_index(g("roads_blocked_pct"), g("access_routes_total"),
                                                    g("access_routes_cut"), g("power_outage_pct"),
                                                    g("comm_outage_pct"), g("critical_facilities_total"),
                                                    g("critical_facilities_affected")),
        "vulnerability": vulnerability_index(g("vulnerable_pop_pct"), g("kutcha_housing_pct")),
    }
