from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator


class HazardType(str, Enum):
    riverine = "riverine"
    urban_pluvial = "urban_pluvial"
    flash_flood = "flash_flood"
    dam_release = "dam_release"
    landslide = "landslide"
    glof = "glof"
    coastal = "coastal"


class ZoneInput(BaseModel):
    """Raw observations for one zone. Every field except `zone_id` is optional: send what you have.
    Missing groups are imputed with neutral values and reported in `missing_inputs` / `confidence`."""
    model_config = ConfigDict(extra="forbid", json_schema_extra={"example": {
        "zone_id": "UK-DHARALI-01", "name": "Dharali, Uttarkashi", "hazard_type": "flash_flood",
        "population": 1800, "flooded_fraction": 0.7, "transient_population": 600,
        "rainfall_24h_mm": 230, "max_inundation_depth_m": 2.5, "flow_velocity_mps": 3.0,
        "incidents_last_1h": 9, "incidents_prev_1h": 1,
        "access_routes_total": 1, "access_routes_cut": 1, "roads_blocked_pct": 100, "comm_outage_pct": 90,
        "vulnerable_pop_pct": 30}})

    zone_id: str = Field(..., min_length=1, max_length=64)
    name: Optional[str] = Field(None, max_length=120)
    hazard_type: Optional[HazardType] = None

    # Exposure
    population: Optional[float] = Field(None, ge=0, le=5e7, description="Resident population of the zone")
    flooded_fraction: Optional[float] = Field(None, ge=0, le=1, description="Share of the zone currently inundated (0-1)")
    forecast_flooded_fraction_6h: Optional[float] = Field(None, ge=0, le=1)
    transient_population: Optional[float] = Field(None, ge=0, le=5e6, description="Pilgrims/tourists/labour camps present")
    population_exposed: Optional[float] = Field(None, ge=0, le=5e7, description="Direct estimate; overrides population x flooded_fraction")

    # Incident growth
    incidents_last_1h: Optional[int] = Field(None, ge=0, description="Rescue requests / 112 calls in the last hour")
    incidents_prev_1h: Optional[int] = Field(None, ge=0, description="... in the hour before that")
    water_level_rise_cm_per_h: Optional[float] = Field(None, ge=-500, le=500)

    # Hazard severity
    rainfall_24h_mm: Optional[float] = Field(None, ge=0, le=2000)
    rainfall_forecast_6h_mm: Optional[float] = Field(None, ge=0, le=1000)
    river_level_above_danger_m: Optional[float] = Field(None, ge=-50, le=50)
    river_headroom_m: Optional[float] = Field(None, gt=0, le=50, description="Highest-flood-level minus danger level (default 3 m)")
    max_inundation_depth_m: Optional[float] = Field(None, ge=0, le=30)
    flow_velocity_mps: Optional[float] = Field(None, ge=0, le=30)

    # Capacity stress
    displaced_people: Optional[float] = Field(None, ge=0)
    shelter_capacity: Optional[float] = Field(None, ge=0)
    hospitals_nonfunctional_pct: Optional[float] = Field(None, ge=0, le=100)
    rescue_assets_available: Optional[float] = Field(None, ge=0)
    rescue_assets_required: Optional[float] = Field(None, ge=0)

    # Infrastructure risk
    roads_blocked_pct: Optional[float] = Field(None, ge=0, le=100)
    access_routes_total: Optional[int] = Field(None, ge=0)
    access_routes_cut: Optional[int] = Field(None, ge=0)
    power_outage_pct: Optional[float] = Field(None, ge=0, le=100)
    comm_outage_pct: Optional[float] = Field(None, ge=0, le=100)
    critical_facilities_total: Optional[int] = Field(None, ge=0)
    critical_facilities_affected: Optional[int] = Field(None, ge=0)

    # Vulnerability
    vulnerable_pop_pct: Optional[float] = Field(None, ge=0, le=100, description="% children<5, elderly 65+, disabled, pregnant")
    kutcha_housing_pct: Optional[float] = Field(None, ge=0, le=100)

    @model_validator(mode="after")
    def _consistency(self):
        if self.access_routes_cut is not None and self.access_routes_total is not None \
                and self.access_routes_cut > self.access_routes_total:
            raise ValueError("access_routes_cut cannot exceed access_routes_total")
        if self.critical_facilities_affected is not None and self.critical_facilities_total is not None \
                and self.critical_facilities_affected > self.critical_facilities_total:
            raise ValueError("critical_facilities_affected cannot exceed critical_facilities_total")
        return self


class Driver(BaseModel):
    factor: str
    index: float
    contribution_points: float
    imputed: bool


class ZoneScore(BaseModel):
    zone_id: str
    name: Optional[str] = None
    priority_score: float = Field(..., description="0-100")
    tier: str = Field(..., description="CRITICAL | HIGH | MODERATE | LOW | UNVERIFIED (no hazard or exposure data)")
    base_score: float = Field(..., description="Weighted-sum score before life-threat uplift")
    life_threat_escalation: bool
    hazard_gate: float
    indices: Dict[str, float] = Field(..., description="The six sub-indices actually used (0-1)")
    contributions: Dict[str, float] = Field(..., description="Points contributed by each factor")
    top_drivers: List[Driver]
    missing_inputs: List[str]
    confidence: float = Field(..., description="Share of model weight backed by real observations")
    ml_shadow_score: Optional[float] = None
    model_disagreement: bool = False
    explanation: str
    model_version: str


class RankedZone(ZoneScore):
    rank: int
    optimizer_weight: float = Field(..., description="Priority share (sums to 1) for the allocation objective")


class RankRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    zones: List[ZoneInput] = Field(..., min_length=1, max_length=5000)
    top_k: Optional[int] = Field(None, ge=1, description="Return only the k highest-priority zones")

    @model_validator(mode="after")
    def _unique_ids(self):
        ids = [z.zone_id for z in self.zones]
        if len(ids) != len(set(ids)):
            raise ValueError("zone_id values must be unique within a request")
        return self


class RankResponse(BaseModel):
    model_version: str
    n_zones: int
    tier_counts: Dict[str, int]
    ranking: List[RankedZone]


class ModelInfo(BaseModel):
    version: str
    formula: str
    weights: Dict[str, float]
    gate_min: float
    gate_tau: float
    escalation: Dict[str, float]
    tier_thresholds: Dict[str, float]
    trained_utc: Optional[str] = None
    method: Optional[str] = None
    disclaimer: Optional[str] = None
