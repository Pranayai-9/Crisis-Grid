"""CrisisGrid Priority Engine v2.

    Priority(i) = 100 * Gate(i) * [ w1*Exposure + w2*IncidentGrowth + w3*HazardSeverity
                                   + w4*CapacityStress + w5*InfrastructureRisk + w6*Vulnerability ]

    Gate(i) = g_min + (1 - g_min) * clip(HazardSeverity / tau, 0, 1)

Changes vs. the 5-term formula in the project report (see docs/FORMULA_REWORK.md):
  * Hazard relevance gate - exposure alone can no longer rank a dry zone above a flooding one.
  * 6th term, Vulnerability.
  * Every sub-index is physically defined, log-scaled where needed, and tolerant of missing data.
  * Weights are learned (constrained, non-negative, sum to 1) and shipped as an auditable JSON artifact.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np

from .features import FACTORS, compute_indices

ARTIFACT_DIR = os.path.join(os.path.dirname(__file__), "artifacts")

FACTOR_LABELS = {
    "exposure": "people in the hazard footprint",
    "incident_growth": "rapid escalation of incidents / water level",
    "hazard_severity": "severe flood hazard",
    "capacity_stress": "local shelter/medical/rescue capacity overwhelmed",
    "infrastructure_risk": "access cut off / lifelines failing",
    "vulnerability": "high share of vulnerable people and fragile housing",
}

DEFAULT_WEIGHTS = {  # used only if no trained artifact is present
    "exposure": 0.25, "incident_growth": 0.15, "hazard_severity": 0.25,
    "capacity_stress": 0.12, "infrastructure_risk": 0.13, "vulnerability": 0.10,
}


def life_threat_uplift(H, I, G, esc):
    """Smooth life-threat uplift (points). Fuzzy-AND of hazard, isolation and escalation via geometric mean,
    then a smoothstep between lt_lo and lt_hi.  Smooth => preserves ordering among escalated zones."""
    lt = np.cbrt(np.clip(H, 0, 1) * np.clip(I, 0, 1) * np.clip(G, 0, 1))
    t = np.clip((lt - esc["lt_lo"]) / (esc["lt_hi"] - esc["lt_lo"]), 0.0, 1.0)
    return esc["max_uplift"] * t * t * (3 - 2 * t)


@dataclass
class ModelCard:
    version: str
    weights: Dict[str, float]
    gate_min: float
    gate_tau: float
    tiers: Dict[str, float]           # lower bounds: critical/high/moderate
    escalation: Dict
    impute: Dict[str, float]          # neutral values for missing sub-indices
    meta: Dict


class PriorityEngine:
    def __init__(self, artifact_dir: str = ARTIFACT_DIR):
        path = os.path.join(artifact_dir, "weights.json")
        if os.path.exists(path):
            with open(path) as f:
                raw = json.load(f)
        else:
            raw = {"version": "untrained-default", "weights": DEFAULT_WEIGHTS, "gate_min": 0.10, "gate_tau": 0.30,
                   "escalation": {"lt_lo": 0.55, "lt_hi": 0.85, "max_uplift": 8.0},
                   "tiers": {"critical": 70.0, "high": 50.0, "moderate": 25.0},
                   "impute": {k: 0.25 for k in FACTORS}, "meta": {"note": "no trained artifact found"}}
        self.card = ModelCard(raw["version"], raw["weights"], raw["gate_min"], raw["gate_tau"],
                              raw["tiers"], raw["escalation"], raw["impute"], raw.get("meta", {}))
        s = sum(self.card.weights.values())
        self.w = {k: self.card.weights[k] / s for k in FACTORS}
        self.gbm = None
        gbm_path = os.path.join(artifact_dir, "gbm_shadow.joblib")
        if os.path.exists(gbm_path):
            try:
                import joblib
                self.gbm = joblib.load(gbm_path)
            except Exception:  # shadow model is optional
                self.gbm = None

    # ------------------------------------------------------------------ core maths
    def gate(self, hazard: float) -> float:
        g0, tau = self.card.gate_min, self.card.gate_tau
        return g0 + (1.0 - g0) * float(np.clip(hazard / tau, 0.0, 1.0))

    def score_indices(self, idx: Dict[str, Optional[float]]) -> Dict:
        missing = [k for k in FACTORS if idx.get(k) is None]
        filled = {k: (idx[k] if idx.get(k) is not None else self.card.impute[k]) for k in FACTORS}
        gate = self.gate(filled["hazard_severity"])
        contrib = {k: 100.0 * gate * self.w[k] * filled[k] for k in FACTORS}
        base_score = float(sum(contrib.values()))
        score, escalated = self.apply_escalation(base_score, filled)
        # confidence: share of total weight backed by real observations; hazard & exposure matter most
        confidence = float(sum(self.w[k] for k in FACTORS if k not in missing))
        shadow = None
        disagreement = False
        if self.gbm is not None:
            x = np.array([[filled[k] for k in FACTORS]])
            raw = float(self.gbm.predict(x)[0])
            m = self.card.meta
            # quantile-map GBM output onto the formula's 0-100 scale so the two are comparable
            shadow = float(np.interp(raw, m["gbm_q"], m["formula_q"])) if "gbm_q" in m else raw * 100.0
            disagreement = abs(shadow - score) > 20.0
        # No hazard or no exposure evidence => the score is mostly imputation: do not assign an operational tier.
        tier = "UNVERIFIED" if ("hazard_severity" in missing or "exposure" in missing) else self.tier(score)
        return {"score": score, "tier": tier, "gate": gate, "indices": filled,
                "contributions": contrib, "base_score": base_score, "escalation_applied": escalated,
                "missing_inputs": missing, "confidence": confidence,
                "ml_shadow_score": shadow, "model_disagreement": disagreement}

    def apply_escalation(self, score: float, idx: Dict[str, float]):
        """Life-threat uplift: severe hazard + cut-off access + fast escalation => up to +max_uplift points.
        Rationale: allocation maximises sum(Priority x Served_demand), so *scale* is already carried by the demand
        term; priority must also express urgency per person.  Exposure does not predict deaths in the historical
        record (Spearman 0.23) whereas hazard, isolation and escalation do (Dharali 2025, Sikkim 2023, Wayanad 2024)."""
        up = float(life_threat_uplift(idx["hazard_severity"], idx["infrastructure_risk"], idx["incident_growth"],
                                      self.card.escalation))
        return min(100.0, score + up), up > 0.5

    def tier(self, score: float) -> str:
        t = self.card.tiers
        if score >= t["critical"]:
            return "CRITICAL"
        if score >= t["high"]:
            return "HIGH"
        if score >= t["moderate"]:
            return "MODERATE"
        return "LOW"

    # ------------------------------------------------------------------ public API
    def score_zone(self, obs: Dict) -> Dict:
        observed = compute_indices(obs)
        res = self.score_indices(observed)
        res["observed_indices"] = observed
        res["drivers"] = self.drivers(res)
        res["explanation"] = self.explain(res, obs)
        return res

    def drivers(self, res: Dict, top: int = 3) -> List[Dict]:
        order = sorted(FACTORS, key=lambda k: res["contributions"][k], reverse=True)
        return [{"factor": k, "index": round(res["indices"][k], 3),
                 "contribution_points": round(res["contributions"][k], 2),
                 "imputed": k in res["missing_inputs"]} for k in order[:top]]

    def explain(self, res: Dict, obs: Dict) -> str:
        name = obs.get("name") or obs.get("zone_id", "zone")
        top = [d for d in res["drivers"] if not d["imputed"]][:3] or res["drivers"][:3]
        reasons = "; ".join(FACTOR_LABELS[d["factor"]] + f" ({d['contribution_points']:.0f} pts)" for d in top)
        if res["tier"] == "UNVERIFIED":
            return (f"{name}: UNVERIFIED - no {'hazard' if 'hazard_severity' in res['missing_inputs'] else 'exposure'} "
                    f"observations received, so no operational tier is assigned (indicative score {res['score']:.0f}/100 "
                    f"from neutral defaults). Collect data or dispatch a verification task.")
        s = f"{name}: {res['tier']} priority ({res['score']:.0f}/100). Main drivers: {reasons}."
        if res["escalation_applied"]:
            s += (f" LIFE-THREAT ESCALATION: severe hazard + access cut-off + rapid escalation added "
                  f"{res['score'] - res['base_score']:.0f} points (base {res['base_score']:.0f}).")
        if res["gate"] < 0.5:
            s += " Score is damped because observed flood hazard is low."
        if res["missing_inputs"]:
            s += f" Inputs missing for: {', '.join(res['missing_inputs'])} (neutral values used; confidence {res['confidence']:.0%})."
        if res["model_disagreement"]:
            s += " ML shadow model disagrees by >20 points - recommend human review."
        return s

    def rank(self, zones: List[Dict]) -> List[Dict]:
        out = []
        for z in zones:
            r = self.score_zone(z)
            r["zone_id"] = z.get("zone_id")
            r["name"] = z.get("name")
            out.append(r)
        out.sort(key=lambda r: r["score"], reverse=True)
        total = sum(r["score"] for r in out) or 1.0
        for i, r in enumerate(out, 1):
            r["rank"] = i
            # normalised weight for the allocation objective  max sum_i Priority_i * Served_i  (report s4.5)
            r["optimizer_weight"] = r["score"] / total
        return out
