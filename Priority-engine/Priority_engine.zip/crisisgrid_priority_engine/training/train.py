"""Train the CrisisGrid priority engine.

    python training/train.py            # writes crisisgrid_priority/artifacts/{weights.json,gbm_shadow.joblib}

Method
  1. Draw K randomised outcome-model configurations (domain randomisation).
  2. For each, simulate flood scenarios across six Indian archetypes (simulate.py).
  3. Fit w on the simplex with a listwise (ListNet/KL) loss inside each scenario: softmax(gamma*Gate*X@w) vs softmax(beta*log10 need).
  4. Source 1 = mean over configurations (spread reported). Source 2 = bagged NNLS on 15 coded historical events.
     Final = 50/50 blend projected onto governance bounds [0.06, 0.30].
  5. Fit a monotone gradient-boosting "shadow" model for disagreement flags.
  6. Derive neutral imputation values and tier thresholds from the simulated score distribution.
"""
from __future__ import annotations

import json
import os
import sys
import time

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

sys.path.insert(0, os.path.dirname(__file__))
from simulate import FACTORS, OutcomeParams, simulate  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ART = os.path.join(ROOT, "crisisgrid_priority", "artifacts")
GATE_MIN, GATE_TAU = 0.10, 0.30
# Life-threat uplift (triage-style, smooth): fuzzy-AND(hazard, isolation, growth) -> up to +8 points (policy dial; see docs trade-off table).
ESCALATION = {"lt_lo": 0.55, "lt_hi": 0.85, "max_uplift": 8.0}
HAZ = FACTORS.index("hazard_severity")


def gate(h, g0=GATE_MIN, tau=GATE_TAU):
    return g0 + (1 - g0) * np.clip(h / tau, 0, 1)


ZONES = 40


def _softmax(a, axis=-1):
    a = a - a.max(axis=axis, keepdims=True)
    e = np.exp(a)
    return e / e.sum(axis=axis, keepdims=True)


def fit_weights(X, ylog, beta=2.0, use_gate=True, cols=None, zones=ZONES, l2=0.0):
    """Listwise (ListNet / KL) fit of the weights inside each scenario.

    Target: p_true = softmax(beta * log10 need) over zones of a scenario - "attention should be spread
    in proportion to need"; prediction: p = softmax(gamma * Priority/100).  Weights are on the simplex.
    """
    from scipy.optimize import minimize
    cols = list(range(X.shape[1])) if cols is None else list(cols)
    S = len(X) // zones
    Xs = X[: S * zones].reshape(S, zones, -1)
    Y = ylog[: S * zones].reshape(S, zones)
    p_true = _softmax(beta * Y)
    g = (gate(Xs[:, :, HAZ]) if use_gate else np.ones((S, zones)))
    Xc = Xs[:, :, cols]
    k = len(cols)

    def loss(theta):
        w = _softmax(theta[:k])
        gamma = np.exp(theta[k])
        z = gamma * g * (Xc @ w)
        logp = z - z.max(axis=1, keepdims=True)
        logp = logp - np.log(np.exp(logp).sum(axis=1, keepdims=True))
        return float(-(p_true * logp).sum(axis=1).mean() + l2 * np.sum((w - 1.0 / k) ** 2))

    theta0 = np.concatenate([np.zeros(k), [np.log(8.0)]])
    res = minimize(loss, theta0, method="L-BFGS-B")
    w = _softmax(res.x[:k])
    full = np.zeros(X.shape[1]); full[cols] = w
    return full


def formula_score(X, w, use_gate=True):
    g = gate(X[:, HAZ]) if use_gate else 1.0
    return 100.0 * g * (X @ w) if use_gate else 100.0 * (X @ w)


W_LO, W_HI = 0.06, 0.30          # governance bounds: no factor ignored, none allowed to dominate
EVENTS_CSV = os.path.join(os.path.dirname(os.path.abspath(__file__)), "historical_events.csv")


def project_bounded_simplex(w, lo=W_LO, hi=W_HI):
    from scipy.optimize import minimize
    k = len(w)
    res = minimize(lambda x: np.sum((x - w) ** 2), np.full(k, 1.0 / k), method="SLSQP",
                   bounds=[(lo, hi)] * k, constraints=[{"type": "eq", "fun": lambda x: x.sum() - 1}])
    return res.x


def event_matrix(noise=0.0, rng=None):
    """Coded factor matrix (6 cols, FACTORS order) and composite outcome of the 15 historical events."""
    import pandas as pd
    from scipy.stats import rankdata
    sys.path.insert(0, ROOT)
    from crisisgrid_priority.features import exposure_index
    d = pd.read_csv(EVENTS_CSV)
    E = np.array([exposure_index(population_exposed=x) for x in d.exposed_pop])
    X = np.column_stack([E, d.G, d.H, d.C, d.I, d.V]).astype(float)
    if noise > 0:
        X[:, 1:] = np.clip(X[:, 1:] + rng.normal(0, noise, X[:, 1:].shape), 0, 1)
    lethal = np.log10(d.deaths_missing.values + 1.0)
    scale = np.log10(d.exposed_pop.values)
    r = lambda v: (rankdata(v) - 1) / (len(v) - 1)
    return d, X, lethal, scale, 0.5 * r(lethal) + 0.5 * r(scale)


def _ridge_simplex(X, o, lam):
    """min ||o - Xw||^2/n + lam*||w - 1/k||^2  s.t. w on the simplex (shrinks toward equal weights)."""
    from scipy.optimize import minimize
    n, k = X.shape
    f = lambda w: np.mean((o - X @ w) ** 2) + lam * np.sum((w - 1.0 / k) ** 2)
    r = minimize(f, np.full(k, 1.0 / k), method="SLSQP", bounds=[(0, 1)] * k,
                 constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1}])
    return r.x


def choose_lambda(X, o, grid=(0.001, 0.01, 0.05, 0.2, 1.0, 5.0)):
    """Leave-one-event-out CV: pick the shrinkage that best ranks the held-out event."""
    from scipy.stats import spearmanr
    out = {}
    for lam in grid:
        pred = np.zeros(len(X))
        for i in range(len(X)):
            m = np.arange(len(X)) != i
            pred[i] = X[i] @ _ridge_simplex(X[m], o[m], lam)
        out[lam] = float(spearmanr(pred, o)[0])
    best = max(out, key=out.get)
    return best, out


def fit_event_weights(X, o, n_boot=300, seed=0):
    """Ridge-on-simplex weights from the 15 events; lambda by LOEO-CV; bootstrap for 5-95% bands."""
    lam, cv = choose_lambda(X, o)
    rng = np.random.default_rng(seed)
    Ws = np.array([_ridge_simplex(X[i], o[i], lam) for i in (rng.integers(0, len(X), len(X)) for _ in range(n_boot))])
    return _ridge_simplex(X, o, lam), np.percentile(Ws, 5, axis=0), np.percentile(Ws, 95, axis=0), lam, cv


def main(n_configs=30, scen_per_cfg=120, seed=2026):
    t0 = time.time()
    rng = np.random.default_rng(seed)
    W, pool_X, pool_y = [], [], []
    for k in range(n_configs):
        op = OutcomeParams.random(rng)
        d = simulate(scen_per_cfg, rng, op)
        W.append(fit_weights(d["X"], d["y"], beta=float(rng.uniform(1.0, 3.0))))
        if k < 10:
            pool_X.append(d["X"]); pool_y.append(d["y"])
    W = np.array(W)
    w_mean, w_sd = W.mean(0), W.std(0)
    w_sim = w_mean / w_mean.sum()                      # source 1: simulator (domain-randomised)
    _, Xe, _, _, oe = event_matrix()
    w_evt, w_evt_lo, w_evt_hi, lam_evt, cv_evt = fit_event_weights(Xe, oe)  # source 2: 15 coded historical events
    w_final = project_bounded_simplex(0.5 * w_sim + 0.5 * w_evt)   # triangulate, then apply governance bounds
    w_final = w_final / w_final.sum()

    PX, Py = np.vstack(pool_X), np.concatenate(pool_y)
    gbm = HistGradientBoostingRegressor(max_depth=4, learning_rate=0.08, max_iter=250,
                                        monotonic_cst=[1] * 6, random_state=0).fit(PX, Py)
    s_formula = formula_score(PX, w_final)
    s_gbm = gbm.predict(PX)
    qs = np.linspace(0, 1, 101)
    tiers = {"critical": float(np.quantile(s_formula, 0.90)), "high": float(np.quantile(s_formula, 0.70)),
             "moderate": float(np.quantile(s_formula, 0.40))}
    impute = {f: float(np.median(PX[:, i])) for i, f in enumerate(FACTORS)}

    # quantile-map GBM output onto the formula's 0-100 scale so both are comparable in the API
    meta = {
        "trained_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "method": "listwise (KL) fit of gated 6-index formula; domain-randomised simulator calibrated to 15 Indian flood events (2008-2025)",
        "n_configs": n_configs, "scenarios_per_config": scen_per_cfg, "zones_per_scenario": 40,
        "weights_simulator": {f: float(x) for f, x in zip(FACTORS, w_sim)},
        "weights_historical_events": {f: float(x) for f, x in zip(FACTORS, w_evt)},
        "weights_historical_events_p05": {f: float(x) for f, x in zip(FACTORS, w_evt_lo)},
        "weights_historical_events_p95": {f: float(x) for f, x in zip(FACTORS, w_evt_hi)},
        "weight_bounds": [W_LO, W_HI],
        "events_ridge_lambda": lam_evt, "events_loeo_spearman_by_lambda": {str(k): v for k, v in cv_evt.items()},
        "weight_sd_across_configs": {f: float(s) for f, s in zip(FACTORS, w_sd)},
        "weight_min_across_configs": {f: float(s) for f, s in zip(FACTORS, W.min(0))},
        "weight_max_across_configs": {f: float(s) for f, s in zip(FACTORS, W.max(0))},
        "gbm_q": [float(x) for x in np.quantile(s_gbm, qs)],
        "formula_q": [float(x) for x in np.quantile(s_formula, qs)],
        "tier_rule": "critical=top10%, high=next20%, moderate=next30% of simulated score distribution",
        "disclaimer": "Weights are calibrated on simulated scenarios + 15 coded historical events. "
                      "Re-train with real operational labels (retrain via training/train.py) before operational use.",
    }
    card = {"version": "2.0.0", "weights": {f: float(w) for f, w in zip(FACTORS, w_final)},
            "gate_min": GATE_MIN, "gate_tau": GATE_TAU, "escalation": ESCALATION, "tiers": tiers, "impute": impute, "meta": meta}
    os.makedirs(ART, exist_ok=True)
    with open(os.path.join(ART, "weights.json"), "w") as f:
        json.dump(card, f, indent=2)
    joblib.dump(gbm, os.path.join(ART, "gbm_shadow.joblib"))
    print(f"trained in {time.time() - t0:.1f}s")
    for f, m, a, b, sd in zip(FACTORS, w_final, w_sim, w_evt, w_sd):
        print(f"  {f:22s} final={m:.3f}  simulator={a:.3f} (sd {sd:.3f})  events={b:.3f}")
    print("tiers:", {k: round(v, 1) for k, v in tiers.items()})


if __name__ == "__main__":
    main()
