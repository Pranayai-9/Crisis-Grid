"""Benchmark the trained engine.  python training/evaluate.py  ->  docs/evaluation_report.json (+ docs/EVALUATION.md)

Tests
  A. Held-out simulated scenarios (fresh random outcome configs) - overall and per hazard archetype
  B. Real-event validation, leave-one-event-out (weights re-derived without the event being scored)
  C. Robustness: weight perturbation, gate parameters, coding noise on the historical events
  D. Named stress cases (the failure modes of the original formula)
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
from scipy.stats import rankdata, spearmanr, kendalltau
from sklearn.ensemble import HistGradientBoostingRegressor

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(__file__))
from simulate import ARCHETYPES, FACTORS, OutcomeParams, simulate  # noqa: E402
sys.path.insert(0, ROOT_DIR)
from crisisgrid_priority.engine import life_threat_uplift  # noqa: E402
from train import (ART, EVENTS_CSV, ROOT, ZONES, event_matrix, fit_event_weights, fit_weights,  # noqa: E402
                   gate, project_bounded_simplex)

K = 5
HAZ = FACTORS.index("hazard_severity")


def load_card():
    return json.load(open(os.path.join(ART, "weights.json")))


def scen_metrics(score, ylog, k=K):
    """score, ylog: (S, zones).  Returns mean spearman, precision@k, need captured@k."""
    S = len(score)
    rho, p, cap = [], [], []
    need = 10 ** ylog
    for s in range(S):
        rho.append(spearmanr(score[s], ylog[s])[0])
        top_p = np.argsort(-score[s])[:k]
        top_t = np.argsort(-ylog[s])[:k]
        p.append(len(set(top_p) & set(top_t)) / k)
        cap.append(need[s, top_p].sum() / need[s, top_t].sum())
    return {"spearman": float(np.nanmean(rho)), f"precision@{K}": float(np.mean(p)), f"need_captured@{K}": float(np.mean(cap))}


def make_scorers(card, gbm_by_holdout=None):
    w = np.array([card["weights"][f] for f in FACTORS])
    w_sim = np.array([card["meta"]["weights_simulator"][f] for f in FACTORS])
    w5 = np.array([0.2, 0.2, 0.2, 0.2, 0.2, 0.0])   # original 5-term, equal weights (report s4.3 baseline)
    w6 = np.full(6, 1 / 6)
    g = lambda X: gate(X[:, :, HAZ])
    esc = card["escalation"]

    def final(X):
        sc = 100 * g(X) * (X @ w)
        return np.minimum(100.0, sc + life_threat_uplift(X[:, :, HAZ], X[:, :, 4], X[:, :, 1], esc))
    return {
        "B0 original 5-term, equal weights, no gate": lambda X: 100 * (X @ w5),
        "B1 6-term equal weights + gate": lambda X: 100 * g(X) * (X @ w6),
        "B2 final weights, no gate": lambda X: 100 * (X @ w),
        "B3 learned weights + gate (no escalation rule)": lambda X: 100 * g(X) * (X @ w),
        "FINAL engine (learned weights + gate + life-threat escalation)": final,
        "ref: simulator-only weights + gate": lambda X: 100 * g(X) * (X @ w_sim),
    }


def part_A(card, rng):
    X_all, Y_all, A_all = [], [], []
    for _ in range(12):                      # fresh outcome configs never seen in training
        op = OutcomeParams.random(rng)
        d = simulate(120, rng, op)
        X_all.append(d["X"]); Y_all.append(d["y"]); A_all.append(d["archetype"])
    X = np.vstack(X_all).reshape(-1, ZONES, 6); Y = np.concatenate(Y_all).reshape(-1, ZONES)
    A = np.concatenate(A_all).reshape(-1, ZONES)[:, 0]
    scorers = make_scorers(card)
    res = {}
    for name, fn in scorers.items():
        res[name] = {"ALL": scen_metrics(fn(X), Y)}
        for a in ARCHETYPES:
            m = A == a
            res[name][a] = scen_metrics(fn(X[m]), Y[m])
    # GBM shadow, leave-one-archetype-out (never saw the archetype or these configs)
    tr_X, tr_y, tr_a = [], [], []
    for _ in range(6):
        op = OutcomeParams.random(rng)
        d = simulate(120, rng, op)
        tr_X.append(d["X"]); tr_y.append(d["y"]); tr_a.append(d["archetype"])
    tr_X, tr_y, tr_a = np.vstack(tr_X), np.concatenate(tr_y), np.concatenate(tr_a)
    key = "ref: GBM (leave-one-archetype-out, unconstrained upper bound)"
    res[key] = {}
    pred_all = np.zeros(Y.shape)
    for a in ARCHETYPES:
        gbm = HistGradientBoostingRegressor(max_depth=4, max_iter=200, learning_rate=0.08, random_state=0
                                            ).fit(tr_X[tr_a != a], tr_y[tr_a != a])
        m = A == a
        pred = gbm.predict(X[m].reshape(-1, 6)).reshape(-1, ZONES)
        pred_all[m] = pred
        res[key][a] = scen_metrics(pred, Y[m])
    res[key]["ALL"] = scen_metrics(pred_all, Y)
    return res, (X, Y, A)


def part_B(card):
    d, X, lethal, scale, o = event_matrix()
    n = len(d)
    w_sim = np.array([card["meta"]["weights_simulator"][f] for f in FACTORS])
    pred_final, pred_eq5, pred_sim = np.zeros(n), np.zeros(n), np.zeros(n)
    for i in range(n):
        m = np.arange(n) != i
        w_evt = fit_event_weights(X[m], o[m], n_boot=30)[0]
        w = project_bounded_simplex(0.5 * w_sim + 0.5 * w_evt); w /= w.sum()
        sc = 100 * gate(X[i, HAZ]) * (X[i] @ w)
        pred_final[i] = min(100.0, sc + float(life_threat_uplift(X[i, HAZ], X[i, 4], X[i, 1], card["escalation"])))
        pred_eq5[i] = 100 * (X[i] @ np.array([.2, .2, .2, .2, .2, 0]))
        pred_sim[i] = 100 * gate(X[i, HAZ]) * (X[i] @ w_sim)
    pop_only = X[:, 0]
    out = {"n_events": n}
    for lab, vec in {"FINAL engine (leave-one-event-out)": pred_final, "B0 original 5-term equal weights": pred_eq5, "simulator-only weights": pred_sim,
                     "exposure only": pop_only}.items():
        out[lab] = {"vs_lethality(deaths+missing)": float(spearmanr(vec, lethal)[0]),
                    "vs_scale(people affected/displaced)": float(spearmanr(vec, scale)[0]),
                    "vs_composite": float(spearmanr(vec, o)[0])}
    out["event_ranking"] = [{"event": r.name, "year": int(r.year), "engine_score": round(float(s), 1), "composite_outcome_rank": round(float(c), 2)}
                            for r, s, c in sorted(zip(d.itertuples(), pred_final, o), key=lambda t: -t[1])]
    return out


def part_C(card, simdata, rng):
    X, Y, A = simdata
    w = np.array([card["weights"][f] for f in FACTORS])
    base = 100 * gate(X[:, :, HAZ]) * (X @ w)   # robustness measured on the additive core
    # (1) weight perturbation: Dirichlet around final weights (concentration 40), keep bounds loosely
    taus, caps = [], []
    for _ in range(100):
        wp = rng.dirichlet(w * 40)
        sp = 100 * gate(X[:, :, HAZ]) * (X @ wp)
        idx = rng.integers(0, len(X), 40)
        taus.append(np.mean([kendalltau(base[i], sp[i])[0] for i in idx]))
        caps.append(scen_metrics(sp[idx], Y[idx])[f"need_captured@{K}"])
    out = {"weight_perturbation": {"mean_kendall_tau_vs_final": float(np.mean(taus)), "min_kendall_tau": float(np.min(taus)),
                                   f"need_captured@{K}_mean": float(np.mean(caps)), f"need_captured@{K}_p05": float(np.percentile(caps, 5))}}
    # (2) gate parameters
    gp = {}
    for g0 in (0.05, 0.10, 0.20):
        for tau in (0.2, 0.3, 0.4):
            gg = g0 + (1 - g0) * np.clip(X[:, :, HAZ] / tau, 0, 1)
            gp[f"g_min={g0},tau={tau}"] = scen_metrics(100 * gg * (X @ w), Y)[f"need_captured@{K}"]
    out["gate_parameter_sensitivity_need_captured"] = gp
    # (3) coding noise on historical events (+-0.1 sd)
    d, Xe, lethal, scale, o = event_matrix()
    rhos = []
    for _ in range(300):
        _, Xn, _, _, _ = event_matrix(noise=0.10, rng=rng)
        s = 100 * gate(Xn[:, HAZ]) * (Xn @ w)
        rhos.append(spearmanr(s, lethal)[0])
    out["event_coding_noise_sd0.1_spearman_vs_lethality"] = {"mean": float(np.mean(rhos)), "p05": float(np.percentile(rhos, 5)),
                                                             "p95": float(np.percentile(rhos, 95))}
    return out


def part_D(card):
    from crisisgrid_priority.engine import PriorityEngine
    eng = PriorityEngine()
    cases = {
        "dry dense city (pop 2.5M, no flooding yet, hazard ~0)": dict(population=2_500_000, flooded_fraction=0.0, rainfall_24h_mm=5),
        "flash-flood hamlet (pop 1,800, cloudburst, bridge+road cut, 2nd surge)": dict(
            hazard_type="flash_flood", population=1800, flooded_fraction=0.7, rainfall_24h_mm=230, max_inundation_depth_m=2.5,
            flow_velocity_mps=3.0, incidents_last_1h=9, incidents_prev_1h=1, access_routes_total=1, access_routes_cut=1,
            roads_blocked_pct=100, comm_outage_pct=90, transient_population=600, vulnerable_pop_pct=30),
        "urban pluvial, hospitals failing (Chennai-like)": dict(
            hazard_type="urban_pluvial", population=900_000, flooded_fraction=0.4, rainfall_24h_mm=330, max_inundation_depth_m=1.5,
            displaced_people=60_000, shelter_capacity=25_000, hospitals_nonfunctional_pct=40, power_outage_pct=60,
            incidents_last_1h=120, incidents_prev_1h=50, vulnerable_pop_pct=22, kutcha_housing_pct=18),
        "riverine plain, slow rise, poor housing (Bihar-like)": dict(
            hazard_type="riverine", population=400_000, flooded_fraction=0.5, river_level_above_danger_m=1.4, river_headroom_m=3,
            water_level_rise_cm_per_h=8, displaced_people=90_000, shelter_capacity=30_000, vulnerable_pop_pct=34, kutcha_housing_pct=60),
    }
    w5 = np.array([0.2] * 5)
    out = {}
    from crisisgrid_priority.features import compute_indices
    for name, obs in cases.items():
        r = eng.score_zone(obs)
        idx = compute_indices(obs)
        v5 = [idx[f] if idx[f] is not None else eng.card.impute[f] for f in FACTORS[:5]]
        out[name] = {"original_5term_equal_weights": round(float(100 * np.dot(w5, v5)), 1), "FINAL": round(r["score"], 1), "tier": r["tier"]}
    return out


def part_E(card, simdata):
    """Policy dial: how much life-threat uplift?  Shows the scale-vs-lethality trade-off explicitly."""
    X, Y, _ = simdata
    w = np.array([card["weights"][f] for f in FACTORS])
    d, Xe, lethal, scale, o = event_matrix()
    rows = []
    for U in (0, 4, 8, 12, 16, 20):
        esc = dict(card["escalation"]); esc["max_uplift"] = U
        sc = np.minimum(100, 100 * gate(X[:, :, HAZ]) * (X @ w) + life_threat_uplift(X[:, :, HAZ], X[:, :, 4], X[:, :, 1], esc))
        se = np.minimum(100, 100 * gate(Xe[:, HAZ]) * (Xe @ w) + life_threat_uplift(Xe[:, HAZ], Xe[:, 4], Xe[:, 1], esc))
        m = scen_metrics(sc, Y)
        rows.append({"max_uplift": U, f"sim_need_captured@{K}": round(m[f"need_captured@{K}"], 3),
                     "events_spearman_lethality": round(float(spearmanr(se, lethal)[0]), 2),
                     "events_spearman_scale": round(float(spearmanr(se, scale)[0]), 2),
                     "events_spearman_composite": round(float(spearmanr(se, o)[0]), 2)})
    return rows


def main():
    rng = np.random.default_rng(777)
    card = load_card()
    A, simdata = part_A(card, rng)
    B = part_B(card)
    C = part_C(card, simdata, rng)
    D = part_D(card)
    E = part_E(card, simdata)
    rep = {"E_uplift_tradeoff": E, "A_held_out_simulation": A, "B_real_event_validation": B, "C_robustness": C, "D_stress_cases": D,
           "weights": card["weights"], "weights_bounds": card["meta"]["weight_bounds"]}
    os.makedirs(os.path.join(ROOT, "docs"), exist_ok=True)
    json.dump(rep, open(os.path.join(ROOT, "docs", "evaluation_report.json"), "w"), indent=2)

    print("\nA. HELD-OUT SIMULATION (all archetypes)  spearman | P@5 | need-captured@5")
    for n, v in A.items():
        m = v["ALL"]; print(f"  {n:62s} {m['spearman']:.3f} | {m['precision@5']:.3f} | {m[f'need_captured@{K}']:.3f}")
    print("\n   need-captured@5 by archetype")
    print("  " + " " * 62 + "  ".join(f"{a[:8]:>8s}" for a in ARCHETYPES))
    for n, v in A.items():
        print(f"  {n:62s} " + "  ".join(f"{v[a][f'need_captured@{K}']:8.3f}" for a in ARCHETYPES))
    print("\nB. REAL EVENTS (n=15) spearman vs lethality | scale | composite")
    for n, v in B.items():
        if isinstance(v, dict):
            print(f"  {n:40s} {v['vs_lethality(deaths+missing)']:.2f} | {v['vs_scale(people affected/displaced)']:.2f} | {v['vs_composite']:.2f}")
    print("\nC. ROBUSTNESS"); print(json.dumps(C, indent=1)[:1800])
    print("\nE. UPLIFT TRADE-OFF"); [print("  ", r) for r in E]
    print("\nD. STRESS CASES"); print(json.dumps(D, indent=1))


if __name__ == "__main__":
    main()
