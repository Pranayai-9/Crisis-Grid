"""Scenario simulator calibrated to Indian flood archetypes (2008-2025).

Why a simulator?  No public, zone-level dataset of "which zone *should* have been served first"
exists for India.  We therefore (1) encode what the historical events teach us about how the six
sub-indices co-occur per hazard archetype (Beta distributions below), and (2) generate the
life-safety-weighted unmet need for each zone from a *physical outcome model that is deliberately
different from the additive priority formula* (thresholds, interactions, hidden variables, noise).
The formula's weights are then learned to predict that outcome.  Because the simulator's own
constants are uncertain, we randomise them (domain randomisation) and report weight dispersion.

Real-event validation (evaluate.py) is the independent check on the result.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np
from scipy.stats import beta as beta_dist, norm

FACTORS = ["exposure", "incident_growth", "hazard_severity",
           "capacity_stress", "infrastructure_risk", "vulnerability"]

# Beta(a,b) per factor, order: E, G, H, C, I, V.  Calibrated to the event table
# (e.g. mountain_flash: low exposure, high hazard, very high isolation - Uttarakhand/HP/Dharali).
ARCHETYPES: Dict[str, Dict] = {
    "riverine_plain": dict(p=[(5, 2), (2, 3), (3, 3), (3, 3), (2, 3), (4, 2.5)], leth=0.0008),   # Bihar, Assam, UP, Tripura
    "urban_pluvial":  dict(p=[(6, 1.8), (3, 3), (4, 2.5), (4, 2.5), (4, 2.5), (3, 3)], leth=0.0020),  # Chennai, Delhi, Vadodara
    "mountain_flash": dict(p=[(2, 4), (4, 2.5), (5, 2), (3, 3), (5, 1.8), (3, 3)], leth=0.0080),   # Uttarakhand, HP, Dharali
    "landslide":      dict(p=[(2, 5), (3.5, 2.5), (6, 2), (3, 3), (4, 2), (3.5, 2.5)], leth=0.0200),  # Wayanad
    "dam_release":    dict(p=[(5, 2), (4, 2.5), (4, 2), (4, 2.5), (3.5, 2.5), (3, 3)], leth=0.0030),  # Kerala 2018/19, Punjab 2025
    "glof":           dict(p=[(1.5, 5), (3.5, 2.5), (7, 1.5), (3, 3), (5, 1.5), (3, 3)], leth=0.0100),  # Sikkim 2023
}
QUIET = [(2, 3), (1, 6), (1, 9), (1.5, 6), (1.5, 6), (3, 3)]   # zones in the district that are not flooded
RHO = np.array([0.10, 0.45, 0.55, 0.45, 0.45, 0.10])            # coupling to a shared "zone severity" factor


@dataclass
class OutcomeParams:
    death_mult: float = 200.0     # one expected death ~ this many people needing urgent help
    hit_center: float = 0.30
    hit_width: float = 0.10
    u0: float = 0.10
    uC: float = 0.50
    uI: float = 0.40
    growth_amp: float = 0.8
    vul_need: float = 0.5
    vul_leth: float = 1.5
    leth_scale: float = 1.0
    noise: float = 0.12

    @staticmethod
    def random(rng: np.random.Generator) -> "OutcomeParams":
        return OutcomeParams(
            death_mult=float(np.exp(rng.uniform(np.log(50), np.log(800)))),
            hit_center=rng.uniform(0.20, 0.40), hit_width=rng.uniform(0.06, 0.15),
            u0=rng.uniform(0.05, 0.20), uC=rng.uniform(0.30, 0.70), uI=rng.uniform(0.20, 0.60),
            growth_amp=rng.uniform(0.4, 1.2), vul_need=rng.uniform(0.3, 0.8), vul_leth=rng.uniform(1.0, 2.0),
            leth_scale=float(np.exp(rng.uniform(np.log(0.5), np.log(2.0)))), noise=rng.uniform(0.08, 0.20))


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def _draw(params, z, rng, n):
    """Gaussian-copula draw of n zones x 6 indices with shared severity factor z."""
    eps = rng.standard_normal((n, 6))
    u = norm.cdf(RHO * z[:, None] + np.sqrt(1 - RHO ** 2) * eps)
    out = np.empty((n, 6))
    for k, (a, b) in enumerate(params):
        out[:, k] = beta_dist.ppf(np.clip(u[:, k], 1e-4, 1 - 1e-4), a, b)
    return out


def outcome(X: np.ndarray, leth: np.ndarray, op: OutcomeParams, rng: np.random.Generator) -> np.ndarray:
    """log10 of life-safety-weighted unmet urgent need in the next 24h."""
    E, G, H, C, I, V = X.T
    P = 10 ** (2.0 + 4.5 * E)                                     # people exposed (matches exposure scaling)
    f = lambda h: _sigmoid((h - op.hit_center) / op.hit_width)
    frac_hit = (f(H) - f(0.0)) / (f(1.0) - f(0.0))                 # 0 when no hazard, ->1 at extreme hazard
    N_hit = P * frac_hit
    warning = rng.beta(2, 2, size=len(E))                          # HIDDEN: lead time, not seen by engine
    lethality = leth * op.leth_scale * H ** 2 * (1 + op.vul_leth * V) * (1 + G) * (0.5 + 0.5 * I) * (1 - 0.5 * warning)
    deaths = N_hit * lethality
    unmet = np.clip(op.u0 + op.uC * C + op.uI * I, 0, 1)
    need = N_hit * unmet * (1 + op.growth_amp * G) * (1 + op.vul_need * V)
    raw = np.log10(1.0 + need + op.death_mult * deaths)
    raw = np.maximum(raw + rng.normal(0, op.noise, size=len(E)), 0.0)
    return raw      # log10 of life-safety-weighted unmet need (people-equivalents)


def simulate(n_scenarios: int, rng: np.random.Generator, op: OutcomeParams, zones: int = 40,
             archetypes: List[str] | None = None) -> Dict[str, np.ndarray]:
    names = archetypes or list(ARCHETYPES)
    Xs, ys, sid, arch = [], [], [], []
    for s in range(n_scenarios):
        a = names[s % len(names)]
        spec = ARCHETYPES[a]
        n_quiet = int(round(zones * rng.uniform(0.15, 0.35)))
        n_act = zones - n_quiet
        z = rng.standard_normal(zones)
        Xa = _draw(spec["p"], z[:n_act], rng, n_act)
        Xq = _draw(QUIET, z[n_act:], rng, n_quiet)
        # quiet zones still keep archetype-like exposure/vulnerability (people live there too)
        Xq[:, 0] = _draw([spec["p"][0]] * 6, z[n_act:], rng, n_quiet)[:, 0]
        X = np.vstack([Xa, Xq])
        leth = np.full(zones, spec["leth"])
        y = outcome(X, leth, op, rng)
        Xs.append(X); ys.append(y); sid.append(np.full(zones, s)); arch.append(np.full(zones, a))
    return {"X": np.vstack(Xs), "y": np.concatenate(ys), "scenario": np.concatenate(sid),
            "archetype": np.concatenate(arch)}
